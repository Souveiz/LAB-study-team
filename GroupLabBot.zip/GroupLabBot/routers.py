router = {"host":"192.168.56.101",
            "port":"830",
            "username":"cisco",
            "password":"cisco123!",
            "hostkey_verify":"False"
        }